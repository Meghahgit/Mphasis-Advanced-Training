package assessment_advanced_java_1;

public class Product_1 {
		private int Productid;
		private String Productname;
		private int Productprice;
		
		Product_1(int Productid , String Productname ,int Productprice){
			this.Productid =Productid;
			this.Productname=Productname;
			this.Productprice=Productprice;
			
			
		}

		public int getProductid() {
			return Productid;
		}
		public String getProductname() {
			return Productname;
		}
		public int getProductprice() {
			return Productprice;
		}

		public String toString(){
			return Productid + "" + Productname + "" + Productprice;
		}
		
		
	}

